server <- function(input, output) {
  
  #2.a Reading Connection File
  output$table1 <- renderTable({
    inputfile <- input$ConnF
    
    if (is.null(inputfile))
      return(NULL)
    
    df1<- read.table(inputfile$datapath)
    table1 <- head(df1, 25) 
    
  })
  
  #2.b Reading DeptF
  output$table2 <- renderTable({
    inputfile <- input$DeptF
    
    if (is.null(inputfile))
      return(NULL)
    
    df2<- read.table(inputfile$datapath)
    table2 <- head(df2, 25) 
    
  })
  
  #3 Display n connections from the file
  output$Net3 <- renderForceNetwork({
    
    #File input - Displaying top N number of observations
    inputfile <- input$ConnF
    if (is.null(inputfile))
      return(NULL)
    Nobs <- input$N
    df3 <- read.table(inputfile$datapath, nrows= Nobs)
    
    Source <- subset.data.frame(df3, select = V1)
    Target <- subset.data.frame(df3, select = V2)
    Networkdata <- data.frame(Source, Target)
    Net3 <- simpleNetwork(Networkdata, charge = -10, zoom =T)
    
  })
    
  #4 Computing number of emails sent by each person
    output$table4 <- renderTable({
      
      #File input
      inputfile <- input$ConnF
      if (is.null(inputfile))
        return(NULL)
      df4 <-read.table(inputfile$datapath)
      
      #Calculating number of emails sent by each individual
      Person <- subset.data.frame(df4, select = V1)
      table4 <- as.data.frame(table(Person), 
                             responseName = "Number_of_emails_sent")
    })
    
    #4_1 Computing top 10 mail senders
    output$table4_1 <- renderTable({
      
      #File input
      inputfile <- input$ConnF
      if (is.null(inputfile))
        return(NULL)
      df4_1 <-read.table(inputfile$datapath)
      
      #Calculating number of emails sent by each individual
      Person <- subset.data.frame(df4_1, select = V1)
      table4_x <- as.data.frame(table(Person), 
                              responseName = "Number_of_emails_sent")
      table4_y <- table4_x[order(-table4_x$Number_of_emails_sent),]
      table4_1 <- head(table4_y,10)
    })
    
  #5 Computing number of emails recieved by each person
    output$table5 <- renderTable({
      
      #File input
      inputfile <- input$ConnF
      if (is.null(inputfile))
        return(NULL)
      df5 <-read.table(inputfile$datapath)
      
      #Calculating number of emails sent by each individual
      Person <- subset.data.frame(df5, select = V2)
      table5 <- as.data.frame(table(Person), 
                              responseName = "Number of emails recieved")
    
    })
    
  #5_1 Computing top 10 mail recievers
    output$table5_1 <- renderTable({
      
      #File input
      inputfile <- input$ConnF
      if (is.null(inputfile))
        return(NULL)
      df5_1 <-read.table(inputfile$datapath)
      
      #Calculating number of emails sent by each individual
      Person <- subset.data.frame(df5_1, select = V2)
      table5_x <- as.data.frame(table(Person), 
                                responseName = "Number_of_emails_sent")
      table5_y <- table5_x[order(-table5_x$Number_of_emails_sent),]
      table5_1 <- head(table5_y,10)
    })
    
    
  #6_1 Computing and displaying upto 2-hop neighbors of top 10 senders
    output$Net6_1 <- renderForceNetwork({
      options(shiny.reactlog=TRUE) 
      
      #File input
      inputfile <- input$ConnF
      if (is.null(inputfile))
        return(NULL)
      
      df6_1 <-read.table(inputfile$datapath)
      colnames(df6_1) <- c("source", "target")
       a<- subset.data.frame(df6_1, select = source)
      t <- table(a)
      V <- sort(t, decreasing = TRUE)
      V1 <- as.data.frame(V[1:10])
      V1_1 <- subset.data.frame(V1, select = a)
      V1_1v <- as.vector(t(V1_1))
      i <- graph_from_data_frame(d = df6_1, directed = F)
      A <- make_ego_graph(i, order=2, V1_1v )
      gu <- simplify(graph.union(A[[1]], A[[2]], A[[3]],A[[4]], A[[5]], A[[6]],A[[7]], A[[8]], A[[9]]
                                 , A[[10]] ,byname = TRUE), remove.multiple = TRUE)
      
      c<- cluster_walktrap(gu)
      m <- membership(c)
      gu1 <- igraph_to_networkD3(gu, group =m,what = "both")
      nodes_e <- data.frame(gu1$nodes,size = 0)
      
      
      Net6_1 <- forceNetwork(Links = gu1$links, Nodes = nodes_e, Source = 'source', Target = 'target'
                   , NodeID = 'name', Group = 'group', fontSize = 15,
                   radiusCalculation = JS("d.nodesize^2"),
                   opacity = .2, Nodesize = 'size',
                   colourScale = JS("d3.scaleOrdinal(d3.schemeCategory50);")
                   ,linkWidth = 1)
     
    })
    
  #6_2 Computing and displaying upto 2 hop neighbors of top 10 recievers
    
    output$Net6_2 <- renderForceNetwork({
      options(shiny.reactlog=TRUE) 
      
      #File input
      inputfile <- input$ConnF
      if (is.null(inputfile))
        return(NULL)
      
      df6_2 <-read.table(inputfile$datapath)
      colnames(df6_2) <- c("source", "target")
      a<- subset.data.frame(df6_2, select = target)
      t <- table(a)
      V <- sort(t, decreasing = TRUE)
      V1 <- as.data.frame(V[1:10])
      V1_1 <- subset.data.frame(V1, select = a)
      V1_1v <- as.vector(t(V1_1))
      i <- graph_from_data_frame(d = df6_2, directed = F)
      A <- make_ego_graph(i, order=2, V1_1v )
      gu <- simplify(graph.union(A[[1]], A[[2]], A[[3]],A[[4]], A[[5]], A[[6]],A[[7]], A[[8]], A[[9]]
                                 , A[[10]] ,byname = TRUE), remove.multiple = TRUE)
      
      c<- cluster_walktrap(gu)
      m <- membership(c)
      gu2 <- igraph_to_networkD3(gu, group =m,what = "both")
      nodes_e <- data.frame(gu2$nodes,size = 1)
      
      
      Net6_2 <- forceNetwork(Links = gu2$links, Nodes = nodes_e, Source = 'source', Target = 'target'
                             , NodeID = 'name', Group = 'group', fontSize = 15,
                             radiusCalculation = JS("d.nodesize^2"),
                             opacity = .2, Nodesize = 'size', charge = 10,
                             colourScale = JS("d3.scaleOrdinal(d3.schemeCategory50);")
                             ,linkWidth = 1)
      
    })
    
    
  #7_1 Computing degree centrality and it's top 10 with highest degree centrality
    output$table7 <- renderTable({
      options(shiny.reactlog=TRUE) 
      
      #File input
      inputfile <- input$ConnF
      if (is.null(inputfile))
        return(NULL)
      
      df7_1 <-read.table(inputfile$datapath)
      edgeList <- df7_1
      colnames(edgeList) <- c("SourceName", "TargetName")
      
      gD1 <- simplify(graph.data.frame(edgeList, directed=FALSE))
      
      nodeList <- data.frame(ID = c(0:(vcount(gD1) - 1)), # because networkD3 library requires IDs to start at 0
                             Person = V(gD1)$name)
      
      # Calculate degree for all nodes
      nodeList <- cbind(nodeList, nodeDegree= igraph::degree(gD1, v = V(gD1), mode = "total"))
      
      #sorting in decreasing order by node degree and taking top 10 
      sortnodelist <- nodeList[order(-nodeList$nodeDegree),]
      table7 <- head(subset.data.frame(sortnodelist,select = Person),10)
      
    })
    
    #7_2 Displaying 2 hop neighbors of top 10 highest degree ids. Respective departments are
    #color coded. Every department is represented by unique colour in graph. 
    
    output$Net7 <- renderForceNetwork({
      options(shiny.reactlog=TRUE) 
      
      #File input
      inputfile <- input$ConnF
      inputfile1 <- input$DeptF
      if (is.null(inputfile))
        return(NULL)
      if (is.null(inputfile1))
        return(NULL)
      
      df7_2 <-read.table(inputfile$datapath)
      df7_2_1 <- read.table(inputfile1$datapath)
      edgeList <- df7_2
      Dept_List <- df7_2_1
      colnames(edgeList) <- c("SourceName", "TargetName")
      colnames(Dept_List) <- c("Person","Dept")
      
      gD1 <- simplify(graph.data.frame(edgeList, directed=FALSE))
      
      nodeList <- data.frame(ID = c(0:(vcount(gD1) - 1)), # because networkD3 library requires IDs to start at 0
                             Person = V(gD1)$name)
      
      # Calculate degree for all nodes
      nodeList <- cbind(nodeList, nodeDegree= igraph::degree(gD1, v = V(gD1), mode = "total"))
      
      #joining nodelist and dept list
      Join <- merge.data.frame(nodeList,Dept_List )
      
      #sorting in decreasing order by node degree and taking top 10 
      sortnodelist <- Join[order(-Join$nodeDegree),]
      top10_degree <- head(subset.data.frame(sortnodelist,select = Person),10)
      
      #plotting 2 hop neighbours for top 10 degree ids
      V1 <- as.vector(t(top10_degree))
      i <- graph_from_data_frame(d = edgeList, directed = F)
      A <- make_ego_graph(i, order=2, V1 )
      gu <- simplify(graph.union(A[[1]], A[[2]], A[[3]] , A[[4]], A[[5]], A[[6]], A[[7]] , A[[8]]
                                 , A[[9]], A[[10]],byname = TRUE), remove.multiple = TRUE)
      
      c<- cluster_walktrap(gu)
      m <- membership(c)
      gu1 <- igraph_to_networkD3(gu, group =m,what = "both")
      nodes_e <- data.frame(gu1$nodes,size = 1 )
      gu1$nodes <- merge.data.frame(gu1$nodes, Dept_List , by.x = "name", by.y = "Person", sort = F )
      
      Net7 <-forceNetwork(Links = gu1$links, Nodes = gu1$nodes, Source = 'source', Target = 'target'
                   , NodeID = 'name', Group = 'Dept' , fontSize = 15,opacity = .9,linkWidth = 1)
    })
    
    
    #8_1 Computing Betweenness centrality and it's top 10 with highest degree centrality
    output$table8 <- renderTable({
      options(shiny.reactlog=TRUE) 
      
      #File input
      inputfile <- input$ConnF
      if (is.null(inputfile))
        return(NULL)
      
      df8_1 <-read.table(inputfile$datapath)
      edgeList <- df8_1
      colnames(edgeList) <- c("SourceName", "TargetName")
      
      gD1 <- simplify(graph.data.frame(edgeList, directed=FALSE))
      
      nodeList <- data.frame(ID = c(0:(vcount(gD1) - 1)), # because networkD3 library requires IDs to start at 0
                             Person = V(gD1)$name)
      
      #Calculating betweenness
      betAll <- igraph::betweenness(gD1)
      betAll.norm <- (betAll - min(betAll))/(max(betAll) - min(betAll))
      nodeList <- cbind(nodeList, nodeBetweenness=100*betAll.norm) # We are scaling the value by multiplying it by 100 for visualization purposes only (to create larger nodes)
      rm(betAll, betAll.norm)
      
      #sorting in decreasing order by node degree and taking top 10 
      sortnodelist <- nodeList[order(-nodeList$nodeBetweenness),]
      table8 <- head(subset.data.frame(sortnodelist,select = Person),10)
      
    })
    
    #8_2 Displaying 2 hop neighbors of top 10 highest betweenness ids. Respective departments are
    #color coded. Every department is represented by unique colour in graph. 
    
    output$Net8 <- renderForceNetwork({
      options(shiny.reactlog=TRUE) 
      
      #File input
      inputfile <- input$ConnF
      inputfile1 <- input$DeptF
      if (is.null(inputfile))
        return(NULL)
      if (is.null(inputfile1))
        return(NULL)
      
      df8_2 <-read.table(inputfile$datapath)
      df8_2_1 <- read.table(inputfile1$datapath)
      edgeList <- df8_2
      Dept_List <- df8_2_1
      colnames(edgeList) <- c("SourceName", "TargetName")
      colnames(Dept_List) <- c("Person","Dept")
      
      gD1 <- simplify(graph.data.frame(edgeList, directed=FALSE))
      
      nodeList <- data.frame(ID = c(0:(vcount(gD1) - 1)), # because networkD3 library requires IDs to start at 0
                             Person = V(gD1)$name)
      #Calculating betweenness
      betAll <- igraph::betweenness(gD1)
      betAll.norm <- (betAll - min(betAll))/(max(betAll) - min(betAll))
      nodeList <- cbind(nodeList, nodeBetweenness=100*betAll.norm) # We are scaling the value by multiplying it by 100 for visualization purposes only (to create larger nodes)
      rm(betAll, betAll.norm)
      
      #joining nodelist and dept list
      Join <- merge.data.frame(nodeList,Dept_List )
      
      #sorting in decreasing order by node degree and taking top 10 
      sortnodelist <- Join[order(-Join$nodeBetweenness),]
      top10_btwns <- head(subset.data.frame(sortnodelist,select = Person),10)
      
      #plotting 2 hop neighbours for top 10 degree ids
      V1 <- as.vector(t(top10_btwns))
      i <- graph_from_data_frame(d = edgeList, directed = F)
      A <- make_ego_graph(i, order=2, V1 )
      gu <- simplify(graph.union(A[[1]], A[[2]], A[[3]] , A[[4]], A[[5]], A[[6]], A[[7]] , A[[8]]
                                 , A[[9]], A[[10]],byname = TRUE), remove.multiple = TRUE)
      
      c<- cluster_walktrap(gu)
      m <- membership(c)
      gu1 <- igraph_to_networkD3(gu, group =m,what = "both")
      nodes_e <- data.frame(gu1$nodes,size = 1 )
      gu1$nodes <- merge.data.frame(gu1$nodes, Dept_List , by.x = "name", by.y = "Person", sort = F )
      
      Net8 <-forceNetwork(Links = gu1$links, Nodes = gu1$nodes, Source = 'source', Target = 'target'
                          , NodeID = 'name', Group = 'Dept' , fontSize = 15,opacity = .9,linkWidth = 1)
      
    })
  
    #9_1 Computing degree centrality and it's top 10 with highest degree centrality
    output$table9 <- renderTable({
      options(shiny.reactlog=TRUE) 
      
      #File input
      inputfile <- input$ConnF
      if (is.null(inputfile))
        return(NULL)
      
      df9_1 <-read.table(inputfile$datapath)
      edgeList <- df9_1
      colnames(edgeList) <- c("SourceName", "TargetName")
      
      gD1 <- simplify(graph.data.frame(edgeList, directed=T))
      
      nodeList <- data.frame(ID = c(0:(vcount(gD1) - 1)), # because networkD3 library requires IDs to start at 0
                             Person = V(gD1)$name)
      
      # Calculate degree for all nodes
      nodeList <- cbind(nodeList, nodeDegree= igraph::degree(gD1, v = V(gD1), mode = "in", normalized = TRUE))
      
      #sorting in decreasing order by node degree and taking top 10 
      sortnodelist <- nodeList[order(-nodeList$nodeDegree),]
      table9 <- head(subset.data.frame(sortnodelist,select = Person),10)
      
    })
    
    #9_2 Displaying 2 hop neighbors of top 10 highest INdegree ids. Respective departments are
    #color coded. Every department is represented by unique colour in graph. 
    
    output$Net9 <- renderForceNetwork({
      options(shiny.reactlog=TRUE) 
      
      #File input
      inputfile <- input$ConnF
      inputfile1 <- input$DeptF
      if (is.null(inputfile))
        return(NULL)
      if (is.null(inputfile1))
        return(NULL)
      
      df9_2 <-read.table(inputfile$datapath)
      df9_2_1 <- read.table(inputfile1$datapath)
      edgeList <- df9_2
      Dept_List <- df9_2_1
      colnames(edgeList) <- c("SourceName", "TargetName")
      colnames(Dept_List) <- c("Person","Dept")
      
      gD1 <- simplify(graph.data.frame(edgeList, directed=T))
      
      nodeList <- data.frame(ID = c(0:(vcount(gD1) - 1)), # because networkD3 library requires IDs to start at 0
                             Person = V(gD1)$name)
      
      # Calculate degree for all nodes
      nodeList <- cbind(nodeList, nodeDegree= igraph::degree(gD1, v = V(gD1), mode = "in", normalized = T))
      
      #joining nodelist and dept list
      Join <- merge.data.frame(nodeList,Dept_List )
      
      #sorting in decreasing order by node degree and taking top 10 
      sortnodelist <- Join[order(-Join$nodeDegree),]
      top10_degree <- head(subset.data.frame(sortnodelist,select = Person),10)
      
      #plotting 2 hop neighbours for top 10 degree ids
      V1 <- as.vector(t(top10_degree))
      i <- graph_from_data_frame(d = edgeList, directed = F)
      A <- make_ego_graph(i, order=2, V1 )
      gu <- simplify(graph.union(A[[1]], A[[2]], A[[3]] , A[[4]], A[[5]], A[[6]], A[[7]] , A[[8]]
                                 , A[[9]], A[[10]],byname = TRUE), remove.multiple = TRUE)
      
      c<- cluster_walktrap(gu)
      m <- membership(c)
      gu1 <- igraph_to_networkD3(gu, group =m,what = "both")
      nodes_e <- data.frame(gu1$nodes,size = 1 )
      gu1$nodes <- merge.data.frame(gu1$nodes, Dept_List , by.x = "name", by.y = "Person", sort = F )
      
      Net7 <-forceNetwork(Links = gu1$links, Nodes = gu1$nodes, Source = 'source', Target = 'target'
                          , NodeID = 'name', Group = 'Dept' , fontSize = 15,opacity = .9,linkWidth = 1)
    })
      
    #Aggregated the emails sent per person, to the department level. Created a table that indicates
    #the number of emails sent and received between each and every department. Table has 3 columns:
    #ColumnA - Department which is sending emails
    #ColumnB - Department which is at reciver end
    #ColumnC - number of emails sent by Department in column A to the respective department in column B
    
    output$table10 <- renderTable({
      options(shiny.reactlog=TRUE) 
      
      #File input
      inputfile <- input$ConnF
      inputfile1 <- input$DeptF
      if (is.null(inputfile))
        return(NULL)
      if (is.null(inputfile1))
        return(NULL)
      
      df10_1 <-read.table(inputfile$datapath)
      df10_1_1 <- read.table(inputfile1$datapath)
      edgeList <- df10_1
      Dept_List <- df10_1_1
      colnames(edgeList) <- c("SourceName", "TargetName")
      colnames(Dept_List) <- c("Person","Dept")
      
      Id <- data.frame(seq(1:length(edgeList$SourceName)))
      df <- cbind(edgeList, Id)
      colnames(df) <- c("SourceName", "TargetName", "Id")
      
      Source <- subset.data.frame(df, select = c("SourceName", "Id"))
      Target <- subset.data.frame(df, select = c("TargetName", "Id"))
      
      S_D <- merge(Source,Dept_List, by.x = "SourceName", by.y = "Person", sort = FALSE )
      colnames(S_D) <- c("SourceName", "Id","SourceDept")
      T_D <- merge.data.frame(Target,Dept_List, by.x = "TargetName", by.y = "Person" , sort=F)
      colnames(T_D) <- c("TargetName","Id", "TargetDept")
      
      S_T_D <- merge.data.frame(S_D,T_D, by = "Id")
      S_T_D$SourceName <- NULL
      S_T_D$TargetName <- NULL
      S_T_D$Id <- NULL
      
      m <- as.data.frame(table(S_T_D))
      colnames(m) <- c("ColumnA", "ColumnB", "ColumnC")
      table10 <-  sqldf("select * from m where ColumnC!= 0")
    })
      
     #10_1Displaying the above table 
      
      output$Net10 <- renderForceNetwork({
        options(shiny.reactlog=TRUE) 
        
        #File input
        inputfile <- input$ConnF
        inputfile1 <- input$DeptF
        if (is.null(inputfile))
          return(NULL)
        if (is.null(inputfile1))
          return(NULL)
        
        df10_2 <-read.table(inputfile$datapath)
        df10_2_1 <- read.table(inputfile1$datapath)
        edgeList <- df10_2
        Dept_List <- df10_2_1
        colnames(edgeList) <- c("SourceName", "TargetName")
        colnames(Dept_List) <- c("Person","Dept")
        
        Id <- data.frame(seq(1:length(edgeList$SourceName)))
        df <- cbind(edgeList, Id)
        colnames(df) <- c("SourceName", "TargetName", "Id")
        
        Source <- subset.data.frame(df, select = c("SourceName", "Id"))
        Target <- subset.data.frame(df, select = c("TargetName", "Id"))
        
        S_D <- merge(Source,Dept_List, by.x = "SourceName", by.y = "Person", sort = FALSE )
        colnames(S_D) <- c("SourceName", "Id","SourceDept")
        T_D <- merge.data.frame(Target,Dept_List, by.x = "TargetName", by.y = "Person" , sort=F)
        colnames(T_D) <- c("TargetName","Id", "TargetDept")
        
        S_T_D <- merge.data.frame(S_D,T_D, by = "Id", sort = F)
        S_T_D$SourceName <- NULL
        S_T_D$TargetName <- NULL
        S_T_D$Id <- NULL
        
        m <- as.data.frame(table(S_T_D))
        colnames(m) <- c("ColumnA", "ColumnB", "ColumnC")
        m <-  sqldf("select * from m where ColumnC!= 0")
        
        sg <- graph_from_data_frame(S_T_D, directed = T)
        
        
        c<- cluster_walktrap(sg)
        m1 <- membership(c)
        gu1 <- igraph_to_networkD3(sg, group =m1,what = "both")
        
        
        Net10 <-forceNetwork(Links = gu1$links, Nodes = gu1$nodes, Source = 'source', Target = 'target'
                     , NodeID = 'name', Group = 'name', fontSize = 15, linkWidth = m$ColumnC*2 ,  
                     charge = -10, 
                     radiusCalculation = JS("d.nodesize^2"), opacity = .5 )
        
    })
      
   #Observations
      output$Observations <- renderText({
      Observations <- "On comparing visualisations of Degree centrality and betweeness centrality
we can see that nodes with higher degree also share high level of betweenness.
When applied on a cohort, there is a high probablity that an individual with
high degree also  enjoys a superior level of betweenness in the cohort. 
It means that individual also acts as a/an bridge/impartant link between other
small groups which translates into higher level of importance.
However, when we compare Indegree to both betweenness and Degree, we find
it is not necessary that a person with higher degree or betweenness also falls
into top Indegree group. It is because, there is no relation between sending 
and recieving emails. A person who recieve tons of emails but sends only few,
might be at the bottom of heirarchy of the department."                       
       
     
        
    
        })
      
}

    

    
    
    
   

install.packages("shinythemes")
install.packages("networkD3")
install.packages("sqldf")
install.packages("igraph")
install.packages("sna")
install.packages("plyr")
#install.packages("shiny")
library(shiny)
library(shinythemes)
library(networkD3)
library(igraph)
library(sna)
library(plyr)
library(sqldf)



if (interactive()) {

#Displaying title and theme in RShiny
ui <- fluidPage(titlePanel("SumantKekre_Social_Network_Analysis"), 
                theme= shinytheme("darkly"),sidebarLayout(
                  sidebarPanel(
                    
                     #prompting user to brwose and input 2 files.
                     fileInput("ConnF", "Select Connection file", multiple = TRUE,
                               accept = NULL, width = "75%", buttonLabel = "Browse"
                               , placeholder = NULL),
                     fileInput("DeptF", "Select Department File", multiple = TRUE,
                               accept = NULL, width = "75%", buttonLabel = "Browse"
                               , placeholder = NULL),
                     numericInput("N", "Number of observations:", 1,
                                  width = "75%")
                     ),

                  mainPanel(
                    tabsetPanel(
                      tabPanel( "File_Upload",
                                (tabsetPanel
                                 (
                                   tabPanel("Connection File", tableOutput("table1")),
                                   tabPanel("Department File", tableOutput("table2"))
                                 )
                                )
                      ),
                      
                      tabPanel("Network", forceNetworkOutput("Net3"),
                      position = c("left", "right")),
                      
                      tabPanel("Mails Sent",
                               tabsetPanel
                               (
                                 tabPanel("Sent count" , tableOutput("table4")),
                                 tabPanel("Top_10_senders", tableOutput("table4_1"))
                               )
                      ),
                      
                      tabPanel("Recieved Count",
                               tabsetPanel
                               (
                                 tabPanel("Mails Recieved", tableOutput("table5")),
                                 tabPanel("Top_10_Recievers", tableOutput("table5_1"))
                               )
                      ),
                      
                      tabPanel("2-Hop Neighbors",
                               tabsetPanel
                               (
                                 tabPanel("Top 10 Senders Network", forceNetworkOutput("Net6_1")),
                                 tabPanel("Top 10 Recivers Network" , forceNetworkOutput("Net6_2"))
                               )
                      ),
                      
                      tabPanel("Degree Centrality",
                               tabsetPanel
                               (
                                 tabPanel("Top 10s", tableOutput("table7")),
                                 tabPanel("2 hop neighbors", forceNetworkOutput("Net7"))
                               )
                               ),
                      
                      tabPanel("Betweenness Centrality",
                               tabsetPanel
                               (
                                 tabPanel("Top 10s", tableOutput("table8")),
                                 tabPanel("2 hop neighbors", forceNetworkOutput("Net8"))
                               )
                      ),
                      
                      tabPanel("INdegree Centrality",
                               tabsetPanel
                               (
                                 tabPanel("Top 10s", tableOutput("table9")),
                                 tabPanel("2 hop neighbors", forceNetworkOutput("Net9"))
                               )
                      ),
                      
                      tabPanel("Department Interaction",
                               tabsetPanel
                               (
                                 tabPanel("Dept. Communications", tableOutput("table10")),
                                 tabPanel(" Inter-Dept Communnication Graph", forceNetworkOutput("Net10"))
                               )
                      ),
                      
                      tabPanel(" Observations", verbatimTextOutput("Observations")
                        
                      )
                    )
                                        )
                )
)}